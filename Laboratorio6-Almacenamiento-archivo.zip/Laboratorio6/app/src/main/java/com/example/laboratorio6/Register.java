package com.example.laboratorio6;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import java.io.FileOutputStream;
import java.io.IOException;
public class Register extends AppCompatActivity {
    private EditText correo;
    private EditText usuario;
    private EditText contra;
    private Button register;
    private static final String FILENAME ="usuario.txt";
    protected void onCreate(Bundle savedInstanceState ){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        setUpView();
    }
    private void setUpView(){
        correo=findViewById(R.id.correo);
        usuario=findViewById(R.id.usuario);
        contra=findViewById(R.id.password);
        register=findViewById(R.id.login);
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view){
                saveFile();
            }
        });
    }
    private void saveFile(){
        String texto1=correo.getText().toString();
        String texto2=usuario.getText().toString();
        String texto3=contra.getText().toString();
        FileOutputStream fileOutputStream=null;
        try {
            fileOutputStream=openFileOutput(FILENAME,MODE_PRIVATE);
            fileOutputStream.write(texto1.getBytes());
            fileOutputStream.write(texto2.getBytes());
            fileOutputStream.write(texto3.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
